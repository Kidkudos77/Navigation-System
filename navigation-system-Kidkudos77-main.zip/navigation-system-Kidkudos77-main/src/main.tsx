import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '../Application Program Interface/App'
import '../Application Program Interface/styles/globals.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

